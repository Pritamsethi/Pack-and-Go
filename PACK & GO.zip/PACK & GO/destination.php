<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>Tourist - Travel Agency HTML Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/animate/animate.min.css" rel="stylesheet">
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
    <style>
        body{
            background-color: black;
        }
        .hidden {
        display: none;
    }
    .container {
        padding: 20px;
    }
    .container h2{
      color: #fff;
    }
    button{
      background-color: black;
    }
    button:hover {
      background-color: #fff;
    }
    button:active{
      background-color: #86B817;
      text-decoration: #fff;
      border: #86B817;
    }
    </style>

</head>
<body>
  <?php
    include_once "Navbar.html";
    ?>
    <div>
        <div class="container py-5">
            <h2>Explore Destinations by <span class="text-primary">Region</span></h2>
        </div>
    </div>
    <div class="container py-1">
        <div class="trend-listing">
            <ul class="nav" id="pills-tab01" role="tablist">
                <li class="nav-item" role="presentation">
                <button class="nav-link active" onclick="showRegion('North')" aria-selected="true">North India</button>
                </li>
                <li class="nav-item" role="presentation">
                <button class="nav-link" onclick="showRegion('South')" aria-selected="false">South India</button>
                </li>
                <li class="nav-item" role="presentation">
                <button class="nav-link" onclick="showRegion('East')">East India</button>
                </li>
                <li class="nav-item" role="presentation">
                <button class="nav-link" onclick="showRegion('West')">West India</button>
                </li>
                <li class="nav-item" role="presentation">
                <button class="nav-link"  onclick="showRegion('Central')" >Central India</button>
                </li>
            </ul>
        </div>
        <!-- < class="North" id="pills-tabContent01"> -->
            <div class="region-content" id="North">
                <div class="container py-4">
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <a href="uttarakhand.php"><img src="https://images.pexels.com/photos/8020071/pexels-photo-8020071.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" class="card-img-top" alt="..."></a>
                        <div class="card-body">
                          <h5 class="card-title">Uttarakhand</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/14337670/pexels-photo-14337670.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Rajasthan</h5>
                        </div>
                      </div>
                    </div>
                  </div><br>
                  <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/19149633/pexels-photo-19149633/free-photo-of-the-humayun-tomb-in-delhi-india.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Uttar Pradesh</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/6776756/pexels-photo-6776756.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Delhi</h5>                         
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/14477905/pexels-photo-14477905.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Ladak</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/8020071/pexels-photo-8020071.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Himachal</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                        <div class="card ">
                          <img src="https://images.pexels.com/photos/20583478/pexels-photo-20583478/free-photo-of-leh-monastry.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                          <div class="card-body">
                            <h5 class="card-title">Jammu & Kashmir</h5>
                          </div>
                        </div>
                      </div>
                  </div>
                  </div>
            </div>
        </div>

            <!-- south India -->
            <div class="region-content hidden" id="South">
                <div class="container py-4">
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/962464/pexels-photo-962464.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Kerela</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/4134644/pexels-photo-4134644.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Karnataka</h5>
                        </div>
                      </div>
                    </div>
                  </div><br>
                  <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/18082625/pexels-photo-18082625/free-photo-of-eglise-de-notre-dame-des-anges-pondicherry-tamil-nadu-india.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Punducherry</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/5138790/pexels-photo-5138790.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Tamil Nadu</h5>                         
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/19160117/pexels-photo-19160117/free-photo-of-a-cow-standing-in-front-of-a-palace.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Andra Pradesh</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/12393589/pexels-photo-12393589.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Andaman</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                        <div class="card ">
                          <img src="https://images.pexels.com/photos/20380693/pexels-photo-20380693/free-photo-of-ramoji-film-city.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                          <div class="card-body">
                            <h5 class="card-title">Telengana</h5>
                          </div>
                        </div>
                      </div>
                  </div>
                  </div>
            </div>
            <!-- east india -->
            <div class="region-content hidden" id="East">
                <div class="container py-4">
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/20397969/pexels-photo-20397969/free-photo-of-gurudongmar-lake.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Sikkim</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://images.pexels.com/photos/4781122/pexels-photo-4781122.jpeg?auto=compress&cs=tinysrgb&w=600" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Arunachal</h5>
                        </div>
                      </div>
                    </div>
                  </div><br>
                  <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://w0.peakpx.com/wallpaper/671/1001/HD-wallpaper-by-mrinal-deka-assam-bihu-flowers-mrinal-deka-mrinal-deka-graphy-nature.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Assam</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://www.tripsavvy.com/thmb/nH70XRDdon8X4r56fYVIXSiHq7Y=/2121x1414/filters:no_upscale():max_bytes(150000):strip_icc()/GettyImages-497825214-22b1f19b7dcb4bd5ad3892accf2f857d.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Meghalaya</h5>                         
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://th.bing.com/th/id/OIP.5HRfnvwKq4q5u9-I4xSRJgHaE7?rs=1&pid=ImgDetMain" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Odisha</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://www.caleidoscope.in/wp-content/uploads/2021/02/Festivals-of-Nagaland-03-Tsukheneyie-festival-.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Nagaland</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                        <div class="card ">
                          <img src="https://th.bing.com/th/id/OIP.WqR7MHQhT6UfrfpmTC_7MQHaEK?rs=1&pid=ImgDetMain" class="card-img-top" alt="...">
                          <div class="card-body">
                            <h5 class="card-title">West Bengal</h5>
                          </div>
                        </div>
                      </div>
                  </div>
                  </div>
            </div>
            <!-- West India -->
            <div class="region-content hidden" id="West">
                <div class="container py-4">
                <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://wallpapercave.com/wp/wp3218383.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Goa</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://wallpapercave.com/wp/wp5281250.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Gujurat</h5>
                        </div>
                      </div>
                    </div>
                  </div><br>
                  <div class="row row-cols-1 row-cols-md-2 g-4">
                    <div class="col">
                      <div class="card">
                        <img src="https://media.istockphoto.com/photos/shore-temple-at-mahabalipuram-tamil-nadu-india-picture-id911257248?k=6&m=911257248&s=170667a&w=0&h=ZHORSpibzCw4kkVaWfnsBRZteT0QXwjlT_8IeeGV7RI=" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Dadra and Hagar Haveli</h5>
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://cdn.britannica.com/20/173820-050-3F256058/Diu-St-Pauls-church-Daman-India.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Daman and Diu</h5>                         
                        </div>
                      </div>
                    </div>
                    <div class="col">
                      <div class="card">
                        <img src="https://tripnxt.com/blog/wp-content/uploads/2020/01/tripnxt_gateway_of_india_mumbai-1536x965.jpg" class="card-img-top" alt="...">
                        <div class="card-body">
                          <h5 class="card-title">Maharastra</h5>
                        </div>
                      </div>
                    </div>
                  </div>
                  </div> 
            </div>
            <!-- central india -->
            <div class="region-content hidden" id="Central">
              <div class="container py-4">
              <div class="row row-cols-1 row-cols-md-2 g-4">
                  <div class="col">
                    <div class="card">
                      <img src="https://i.pinimg.com/originals/76/ea/fa/76eafaae078b371af63af52a49b254bc.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Madhya Pradesh</h5>
                      </div>
                    </div>
                  </div>
                  <div class="col">
                    <div class="card">
                      <img src="https://alternativetoursindia.com/wp-content/uploads/2018/10/chhattisgarh-tribal-tours.jpg" class="card-img-top" alt="...">
                      <div class="card-body">
                        <h5 class="card-title">Chattisgarh</h5>
                      </div>
                    </div>
                  </div>
                </div>
                </div>
                </div>
  <?php
    include_once "footer.html";
  ?>
     


   
   <script>
        
    // Function to show/hide region content based on selected region
    function showRegion(region) {
        // Hide all region content divs
        const regionContents = document.querySelectorAll('.region-content');
        regionContents.forEach(content => {
            content.classList.add('hidden');
        });

        // Show the selected region content
        const selectedRegionContent = document.getElementById(region);
        if (selectedRegionContent) {
            selectedRegionContent.classList.remove('hidden');
        }
    }

        </script>

     <!-- JavaScript Libraries -->
     <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
     <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
     <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>

     <!-- <script src="lib/wow/wow.min.js"></script>
     <script src="lib/easing/easing.min.js"></script>
     <script src="lib/waypoints/waypoints.min.js"></script>
     <script src="lib/owlcarousel/owl.carousel.min.js"></script>
     <script src="lib/tempusdominus/js/moment.min.js"></script>
     <script src="lib/tempusdominus/js/moment-timezone.min.js"></script>
     <script src="lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
 
     <-- Template Javascript -->
      <script src="main.js"></script> 
 </body>
 
 </html>
