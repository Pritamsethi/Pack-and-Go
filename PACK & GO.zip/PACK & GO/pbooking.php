<?php session_start() ?>
<?php include_once "Navbar.php" ?><br><br><br><br><br>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    require_once "connect.php";
    $id = $_SESSION['user_id'];
    $qry = "SELECT * FROM book WHERE user_id = $id";
    $res = $conn->query($qry);
    if($res->num_rows > 0){
        $row=$res->fetch_assoc();
        ?>
            <div class="">
                <div class="">
                    <div class="">
                        <div class="card">
                            <h3>Destination: <?php echo $row['destination']; ?></h3>
                            <h4>Email: <?php echo $row['email']; ?></h4>
                            <a href="details.php?bookid=<?php echo $row['book_id']; ?>&pid=<?php echo $row['packageid']; ?>" class="btn btn-primary">View Details</a>
                        </div>
                    </div>
                </div>
            </div>
        <?php
    }


    ?>
</body>
</html>