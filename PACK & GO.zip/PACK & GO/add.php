
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Event Registration Form</title>
    <!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">

<!-- jQuery library -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

<!-- Popper JS -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>

<!-- Latest compiled JavaScript -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
<style>
    *{
    margin:0;
    padding:0;
}
body{
    background-color: rgb(187,143,206);
}
.box{
    width:600px;
    height:500px;
    background-color: #fff;
    margin:auto;
    margin-top: 40px;
    border-radius: 5px;
}
.box .header{
    background-color: #000;
    border-top-left-radius: 5px;
    border-top-right-radius: 5px;
}
.box .header p{
    text-align: center;
    padding:5px;
    font-size: 20px;
    color:#fff;
    font-family: sans-serif;
}
form{
    display: flexbox;
    width:540px;
    height:auto;
    margin:auto;
    padding:5px;
}
.row{
    padding:8px;
    margin-top: 7px;
}
.row .col-2{
    text-align: center;
}
.row .col-4 input{
    background:#f2f2f2;
    border:none;
    outline: none;
    padding:3px;
    border-radius: 5px;
}
.row .col-8 input{
    background:#f2f2f2;
    border:none;
    outline: none;
    padding:3px;
    border-radius: 5px;
    width:385px;
}
.row .col-3 input{
    background:#f2f2f2;
    border:none;
    outline: none;
    padding:3px;
    border-radius: 5px;
    width:100px;
}
.row .col-5 input{
    background:#f2f2f2;
    border:none;
    outline: none;
    padding:3px;
    border-radius: 5px;
    width:247px;
}
.row .col-6 p{
    text-align: center;
}
.row .col-6 input{
    margin-left: 20px;
}
.row .col-6 button{
    margin-left: 50px;
}
</style>
</head>
<body>
    
    <div class="box">
        <div class="header">
            <p>Add Festival</p>
        </div>

        <form method="POST">

            <div class="row">
                <div class="col-2" >
                    <p>Date:</p>
                </div>
                <div class="col-4">
                    <input type="date" id="sdate" name="sdate">
                    <small>Start Date</small>
                </div>
                <div class="col-4">
                    <input type="date" class="ml-4" id="edate" name="edate">
                    <small class="ml-4">End Date</small>
                </div>
            </div>

            <div class="row">
                <div class="col-2">
                    <p>Name:</p>
                </div>
                <div class="col-8">
                    <input type="text" id="name" name="name">
                </div>
            </div>

            <div class="row">
                <div class="col-2">
                    <p>State:</p>
                </div>
                <div class="col-8">
                    <input type="text" id="state" name="state">
                </div>
            </div>

            
            <div class="row">
                <div class="col-2">
                    <p>About Festival:</p>
                </div>
                <div class="col-8">
                    <textarea cols="50" row="20" id="des" name="des"></textarea>
                </div>
            </div><br><br>
            <div class="row">
                <div class="col-6">
                    <button  class="btn btn-danger"  id="submit" name="submit" >Add</button>
                </div>
            </div>

        </form>
        <?php
        if(isset($_POST['submit'])){
        require_once "connect.php";

        $sdate=$_POST['sdate'];
        $edate=$_POST['edate'];
        $name=$_POST['name'];
        $state=$_POST['state'];
        $des=$_POST['des'];

        $qry="INSERT INTO festival VALUES('$sdate','$edate','$name','$state','$des')";
        $res=$conn->query($qry);
        $conn->close();
    }
    ?>
    </div>
</body>
</html>