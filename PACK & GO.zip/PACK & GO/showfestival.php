<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  </head>
  <body>
  <div class="content">
    <div>
        <h3>List of the festivals</h3>
    </div>
  </div>  
  <div cllass=>
    
  <table class="table-warning">
  <tr class="table-warning">
    <th>FESTIVAL</th>
    <th>STATE</th>
    <th>START DATE</th>
    <th>END DATE</th>
    <th>DESCRIPTION</th>
  </tr>
  <?php
    require_once "connect.php";

    $qry="SELECT * FROM festival";
    $res = $conn->query($qry);
    while($row=$res->fetch_assoc()){
    ?>
    <tr>
        <td><?php echo $row['name']; ?></td>
        <td><?php echo $row['state']; ?></td>
        <td><?php echo $row['sdate']; ?></td>
        <td><?php echo $row['edate']; ?></td>
        <td><?php echo $row['des']; ?></td>
    </tr>
    <?php
    }
    ?>
  </table>
  </div>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>