<?php

    require_once "connect.php";
    $price = $_POST['price'];
    $day = $_POST['day'];
    $person = $_POST['person'];

    $qry = "INSERT INTO bookings VALUES ('', '$day', '$person', '$price', 'wpfdmwfdmowfdm')";

    $res = $conn->query($qry);
    if($res){
        echo "Successfull";
    }else{
        echo $conn->error;
    }

?>