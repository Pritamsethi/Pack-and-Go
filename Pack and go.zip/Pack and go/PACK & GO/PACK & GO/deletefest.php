<?php
    if(!isset($_GET['fest_id'])){
        header("location:showfestival.php");
    }
    require_once "connect.php";
    $id=$_GET['fest_id'];
    $qry="DELETE FROM festival WHERE fest_id=$id";
    if($conn->query($qry)){
        header("location:showfestival.php?");
    }