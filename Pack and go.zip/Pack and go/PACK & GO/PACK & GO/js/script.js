const signUpButton = document.getElementById('signUpButton');
const signInButton = document.getElementById('signInButton');
const signInForm = document.getElementById('signIn');
const signUpForm = document.getElementById('signup');

// Function to validate email
function validateEmail(email) {
    // Regular expression for email validation
    const re = /\S+@\S+\.\S+/;
    return re.test(email);
}

signUpButton.addEventListener('click', function () {
    signInForm.style.display = "none";
    signUpForm.style.display = "block";
});

signInButton.addEventListener('click', function () {
    signInForm.style.display = "block";
    signUpForm.style.display = "none";
});

// Additional validation for the forgot password form
const forgotPasswordForm = document.getElementById('forgotPasswordForm');
if (forgotPasswordForm) {
    forgotPasswordForm.addEventListener('submit', function (event) {
        const emailInput = document.getElementById('email');
        const newPasswordInput = document.getElementById('new_password');

        let isValid = true;

        // Validate email
        if (!validateEmail(emailInput.value)) {
            alert('Please enter a valid email address.');
            isValid = false;
        }

        // Validate new password
        const newPassword = newPasswordInput.value;
        if (newPassword.length < 8) {
            alert('Password must be at least 8 characters long.');
            isValid = false;
        } else if (!/[a-z]/.test(newPassword)) {
            alert('Password must contain at least one lowercase letter.');
            isValid = false;
        } else if (!/[A-Z]/.test(newPassword)) {
            alert('Password must contain at least one uppercase letter.');
            isValid = false;
        } else if (!/\d/.test(newPassword)) {
            alert('Password must contain at least one digit.');
            isValid = false;
        }

        if (!isValid) {
            event.preventDefault(); // Prevent form submission if validation fails
        }
    });
}

