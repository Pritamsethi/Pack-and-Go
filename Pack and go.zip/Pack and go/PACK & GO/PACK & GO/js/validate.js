function validate(e)
{
    try{
        let email= document.getElementById("email").value
        let password=document.getElementById("password").value
        let cpassword=document.getElementById("cpassword").value
        let error=false;

        let emailerror = document.getElementById("emailerror");
        let passworderror = document.getElementById("passworderror");
        let cpaswworderror = document.getElementById("cpassworderror");

        let emailPat = /^[\w\.]{4,}@[a-zA-Z\.]{5,}\.[a-zA-Z]{2,}/
        if(email === "" || email === null){
        emailerror.innerHTML = "email is Required"
        error = true;
        } else if(!email.match(emailPat)){
        emailerror.innerHTML = "Please enter a valid email id"
        error = true;
        } else {
        emailerror.innerHTML = ""
        }

        let passPat = /(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*]).{8,16}$/
        if(password === "" || password === null){
        passwordError.innerHTML = "password is Required"
        error = true;
        } else if(!password .match(passPat)){
        passworderror.innerHTML = "Please enter a strong password(8-16) with uppercase lowercase numbers & special chars."
        error = true;
        }else {
        passworderror.innerHTML = ""
        }
        if(cpassword === "" || cpassword === null){
        cpassworderror.innerHTML = "confirm password is Required"
        error = true;
        } else if(cpassword !== password){
        cpassworderror.innerHTML = "confirm password must be same as password"
        error = true;
        } else {
        cpassworderror.innerHTML = ""
        }
        if(error){
        e.preventDefault()
        }
        } catch(error){
        console.log(error);
        e.preventDefault()
        }
}


