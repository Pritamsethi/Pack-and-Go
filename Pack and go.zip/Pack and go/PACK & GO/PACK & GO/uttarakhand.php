<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        .card-img-top,
        .card-title {
            transition: transform 0.3s ease;
        }

        .card:hover .card-img-top {
            transform: scale(1.1);
        }
    </style>
    <title>Top Attractions in Uttrakhand</title>
</head>
<body>
    <?php
        include_once "Navbar.php";
    ?><br><br><br>
    <div class="container mt-5">
        <h1 class="text-center mb-5" style="color: black;">Top Attractions in Uttrakhand</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="rishikesh.php">
                        <img src="https://www.holidify.com/images/bgImages/RISHIKESH.jpg" class="card-img-top" alt="Gulmarg Gondola" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Rishikesh</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Auli.php">
                        <img src="https://www.holidify.com/images/bgImages/AULI.jpg" class="card-img-top" alt="Dal Lake" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Auli</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Nainital.php">
                        <img src="https://www.holidify.com/images/bgImages/NAINITAL.jpg" class="card-img-top" alt="Mughal Gardens, Srinagar" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Nainital</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Dehratum.php">
                        <img src="https://www.holidify.com/images/bgImages/DEHRADUN.jpg" class="card-img-top" alt="Shalimar Bagh Mughal Garden" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Dehratun</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Haridwar.php">
                        <img src="https://www.holidify.com/images/bgImages/HARIDWAR.jpg" class="card-img-top" alt="Vaishno Devi Mandir"height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Haridwar</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Kedarnath.php">
                        <img src="https://www.holidify.com/images/bgImages/KEDARNATH.jpg" class="card-img-top" alt="Amarnath Cave" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Kedarnath</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <?php
        include_once "footer.html";
    ?>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
