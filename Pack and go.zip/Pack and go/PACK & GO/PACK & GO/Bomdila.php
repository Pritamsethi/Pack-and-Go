<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Bomdila</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Bomdila</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t3.ftcdn.net/jpg/03/91/26/74/240_F_391267416_we4gfAqZlDjAa44zyVf1JxOOWdF2fo0S.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Bomdila is the headquarters of West Kameng district in the state of Arunachal Pradesh in India. Bomdila is one of the 60 constituencies of the state of Arunachal Pradesh.Bomdila is located at 27.25°N 92.4°E.[1] It has an average elevation of 2415 metres (7923 feet).

                Climate: In Bomdila, the wet season is cool and mostly cloudy and the dry season is cold and clear. Over the course of the year, the temperature typically varies from 31 °F to 66 °F and is rarely below 27 °F or above 70 °FAs of 2001 India census,[3] Bomdila had a population of 6685. Males constitute 54% of the population and females 46%. Bomdila has an average literacy rate of 69%, higher than the national average of 59.5%; with male literacy of 75% and female literacy of 63%. 13% of the population is under 6 years of age. It is inhabited by the Monpa, Sherdukpen, Miji, Bugun (Khowa) and Aka tribes.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Boimdila" class="stretched-link">Want to know more about Bomdila Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/07/0c/36/07/lungta-residency.jpg?w=300&h=300&s=1" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Lungta Residency</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g858482-d6503603-Reviews-Lungta_Residency-Bomdila_West_Kameng_District_Arunachal_Pradesh.html"><strong>Website:</strong>Lungta Residency</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/16/3f/d9/62/view.jpg?w=300&h=300&s=1" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Tsepal Yongjam</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g858482-d2414893-Reviews-Tsepal_Yongjam-Bomdila_West_Kameng_District_Arunachal_Pradesh.html"><strong>Website:</strong>Tsepal Yongjam</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/16/29/27/70/rooms.jpg?w=300&h=300&s=1" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Anu Homestay</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g858482-d13434772-Reviews-Anu_Homestay-Bomdila_West_Kameng_District_Arunachal_Pradesh.html"><strong>Website:</strong>Anu Homestay</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
