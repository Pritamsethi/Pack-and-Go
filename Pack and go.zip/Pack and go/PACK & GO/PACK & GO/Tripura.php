
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        
        .card-img-top,
        .card-title {
            transition: transform 0.3s ease;
        }

        .card:hover .card-img-top {
            transform: scale(1.1);
        }
    </style>
    <title>Top Attractions in Tripura</title>
</head>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br>
    <div class="container mt-5">
        <h1 class="text-center mb-5" style="color: black;">Top Attractions in Tripura</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Agartala.php">
                        <img src="https://www.holidify.com/images/bgImages/AGARTALA.jpg" class="card-img-top" alt="Gulmarg Gondola" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Agartala</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Kailashahra.php">
                        <img src="https://www.holidify.com/images/bgImages/KAILASHAHAR.jpg" class="card-img-top" alt="Dal Lake" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Kailashahar</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Unakoti.php">
                        <img src="https://www.holidify.com/images/bgImages/UNAKOTI.jpg" class="card-img-top" alt="Mughal Gardens, Srinagar" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Unakoti</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/800px-Neermahal_Tripura_Agartala_India_20190803013712.jpg" class="card-img-top" alt="Shalimar Bagh Mughal Garden" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Rudrasagar Lake</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/nirmahal_20210714101322.jpg" class="card-img-top" alt="Vaishno Devi Mandir"height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Nirmahal</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/Ambassa1_20200605105147_20200605105208.jpg" class="card-img-top" alt="Amarnath Cave" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Ambassa</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php
        include_once "footer.html";
    ?>
</body>
</html>
