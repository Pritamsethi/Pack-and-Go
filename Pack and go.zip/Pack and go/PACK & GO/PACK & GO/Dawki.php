<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Dawki</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Dawki</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t4.ftcdn.net/jpg/04/78/10/45/240_F_478104522_4Xf8Ji3rsQeTBaMJWgoenFybjLzSQAcn.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Dawki or Dauki is a town in West Jaintia Hills district, Meghalaya, India.Dawki Integrated Check Post or Dawki border crossing is on Dawki-Tamabil is one of the few road border crossings between India and Bangladesh in West Jaintia Hills district in the state of Meghalaya, India, the corresponding post in Bangladesh is Tamabil post. Dawki ICP foundation stone was laid in January 2017 and will become operation in 2-18.[2] It is used mainly for coal transportation to Bangladesh. Some 500 trucks cross the border every day in peak season.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Dawki" class="stretched-link">Want to know more about Dawki Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://cf.bstatic.com/xdata/images/hotel/square600/526097788.webp?k=067db2c616f828560df95b2d4e184513bf86c6187ba4aba4c0d41f34ae9e757b&o=" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> The Dawki View Guest House</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/searchresults.en-gb.html?aid=306395&label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&no_rooms=1&srpvid=18d9260db32e0167&highlighted_hotels=11500096&redirected=1&city=900059749&hlrd=no_dates&group_adults=2&source=hotel&group_children=0&expand_sb=1&keep_landing=1&sid=d0d4c968d398ce2981cb6126e206ec9b"><strong>Website:</strong> The Dawki View Guest House</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://cf.bstatic.com/xdata/images/hotel/square600/515428476.webp?k=c25af26c0e065fa198c19f8a4b291c7469cd1eb6b14e217c0d3e45ee2ce917d6&o=" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">   The Dawki View Guest House</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/vesta-wood-orchid-resort.en-gb.html?aid=306395&label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&sid=d0d4c968d398ce2981cb6126e206ec9b&dest_id=900059749;dest_type=city;dist=0;group_adults=2;group_children=0;hapos=3;hpos=3;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;srepoch=1716269377;srpvid=483d2697812301ac;type=total;ucfs=1&"><strong>Website:</strong>  The Dawki View Guest House</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="hhttps://cf.bstatic.com/xdata/images/hotel/square600/528693094.webp?k=42e6ccafaf0fb02edf793c869729a0c951a9bced5a69a6d7ca5afb4bb1ef395e&o=" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> Apurna Guest House DawkiOpens in new window
</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/apurna-guest-house-dawki.en-gb.html?aid=306395&label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&sid=d0d4c968d398ce2981cb6126e206ec9b&dest_id=900059749;dest_type=city;dist=0;group_adults=2;group_children=0;hapos=1;hpos=1;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;srepoch=1716269466;srpvid=d5b426c9578f008c;type=total;ucfs=1&"><strong>Website:</strong> Apurna Guest House DawkiOpens in new window
</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
