<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Vrindavan</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Vrindavan</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t3.ftcdn.net/jpg/06/63/73/16/240_F_663731693_t8TXtVJf8ggFWPdLxnECBd0cPzQttncg.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Vrindavan (pronunciationⓘ; IAST: Vṛndāvana), also spelt Vrindaban and Brindaban,[3] is a historical city in the Mathura district of Uttar Pradesh, India. It is located in the Braj Bhoomi region and holds religious importance for Hindus who believe that Krishna, one of the main deities in Hinduism, spent most of his childhood in this city.[4][5][6][7] Vrindavan has about 5,500 temples dedicated to the worship of Krishna and his chief consort, Radha.[8] It is one of the most sacred places for Vaishnava traditions.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Vrindavan" class="stretched-link">Want to know more about Vrindavan Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/04/70/12/e8/nidhivan-hotel.jpg?w=300&h=300&s=1" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> Nidhivan Sarovar Portico</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g951350-d4260168-Reviews-Nidhivan_Sarovar_Portico-Vrindavan_Mathura_District_Uttar_Pradesh.html"><strong>Website:</strong> Nidhivan Sarovar Portico</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/21/d7/42/b7/guest-lobby.jpg?w=300&h=300&s=1" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">  Best Western Vrindavan</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g951350-d23776985-Reviews-Best_Western_Vrindavan-Vrindavan_Mathura_District_Uttar_Pradesh.html"><strong>Website:</strong> Best Western Vrindavan</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/2b/4a/7d/4c/lobby.jpg?w=300&h=300&s=1" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Hotel Idhayan Palace</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g951350-d23423707-Reviews-Hotel_Idhayan_Palace-Vrindavan_Mathura_District_Uttar_Pradesh.html"><strong>Website:</strong>Hotel Idhayan Palace</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
