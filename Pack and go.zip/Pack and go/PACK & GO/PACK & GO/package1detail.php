<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body{
            font-family: 'Nunito', sans-serif;
        }
    </style>
  </head>
  <body>
    <?php
    require_once "Navbar.php";
    ?><br><br><br><br><br>
    <div>
        <h2>Description:</h2>
    </div>
    <div>
        <ul>
            <li>Customized Itineraris: Offer personalized travel plans based on customer preferences and interests.</li>
            <li>Cultural experiences: Provide opportunities to explore local culture through guided tours, traditional meals, and cultural performances.</li>
            <li>Nature & Wildlife: Organize trips to national parks, safaris, bird-watching tours, and biological gardens.</li>
        </ul>
    </div><br><br><br>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <?php
    require_once "footer.html";
    ?>
  </body>
</html>