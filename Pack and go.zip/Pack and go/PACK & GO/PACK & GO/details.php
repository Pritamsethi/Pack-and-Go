<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php
    include_once "Navbar.php";
    ?>
    <br><br><br><br><br>
    <?php
    $bookid = $_GET['bookid'];
    $pid = $_GET['pid'];

    require_once "connect.php";
    $user_id = $_SESSION['user_id'];
    $sql = "SELECT * FROM book INNER JOIN users ON book.user_id=users.id INNER JOIN bookings ON bookings.packageid=book.packageid WHERE book.user_id=$user_id AND book.packageid=$pid AND book.book_id=$bookid";
    $res = $conn->query($sql);
    if($res->num_rows > 0){
        $row=$res->fetch_assoc();
        ?>
        <div class="">
                <div class="">
                    <div class="">
                        <div class="card">
                            <h3>Total Number of Days: <?php echo $row['duration']; ?></h3>
                            <h4>No of person: <?php echo $row['persons']; ?></h4>
                            <h4>Price: <?php echo $row['price']; ?></h4>
                        </div>
                    </div>
                </div>
            </div>
        <?php
    }

    ?>
    <?php
    include_once "footer.html";
    ?>
</body>
</html>