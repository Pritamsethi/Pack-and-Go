<?php
    if(!isset($_GET['review_id'])){
        header("location:adminreview.php");
    }
    require_once "connect.php";
    $id=$_GET['review_id'];
    $qry="DELETE FROM reviews WHERE review_id=$id";
    if($conn->query($qry)){
        header("location:adminreview.php");
    }