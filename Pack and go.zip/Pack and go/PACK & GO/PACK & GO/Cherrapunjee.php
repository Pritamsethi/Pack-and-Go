<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Cherrapunjee</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Cherrapunjee</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t4.ftcdn.net/jpg/04/94/72/51/240_F_494725187_6Jm5MDojAadfGJX844HkTRQNLVwfdV2Q.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Cherrapunji (/ˌtʃɛrəˈpʌndʒi, -ˈpʊn-/ ⓘ) or Sohra is a sub-divisional town (Proposed District) East Khasi Hills district in the Indian state of Meghalaya. It was the traditional capital of ka hima Sohra (Khasi tribal kingdom).

                Sohra has often been credited as being the wettest place on Earth, but currently, nearby Mawsynram holds that distinction. Sohra still holds the all-time record for the most rainfall in a calendar month and in a year, however. It received 9,300 millimetres (370 in; 30.5 ft) in July 1861 and 26,461 millimetres (1,041.8 in; 86.814 ft) between 1 August 1860 and 31 July 1861.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Cherrapunjee" class="stretched-link">Want to know more about Cherrapunjee Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://cf.bstatic.com/xdata/images/hotel/square600/298172658.webp?k=5898b18ebdc42b2795032f60ba0bd365e8b956a77b5f7684775a0d5bfb61ca9c&o=" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> 7 Sisters Falls View Inn</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/7-sisters-falls-view-inn-cherrapunjee1.en-gb.html?label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&gclid=Cj0KCQjw6auyBhDzARIsALIo6v901vGcp34ucB62pIDTt2v5X3EFQtTuDHOFJazz66HUHu53v8H7GmMaAnPUEALw_wcB&aid=306395"><strong>Website:</strong> 7 Sisters Falls View Inn</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://cf.bstatic.com/xdata/images/hotel/square600/379748628.webp?k=dea35a7c3d15cdb87e6ccf944151669cff1a17d4aa97f70ed6b5aadf178e72d6&o=" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">   Sulawado Resort</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/sulawado-resort-cherrapunji.en-gb.html?label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&gclid=Cj0KCQjw6auyBhDzARIsALIo6v901vGcp34ucB62pIDTt2v5X3EFQtTuDHOFJazz66HUHu53v8H7GmMaAnPUEALw_wcB&aid=306395"><strong>Website:</strong>  Sulawado Resort</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://cf.bstatic.com/xdata/images/hotel/square600/555111270.webp?k=b6c8d72ff9d924f82b97b0819d55bb7ab13dfc37703722716f383d284e7e951d&o=" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> Abode Me Me Ai Haven</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/abode-budget-stay-cherrapunjee.en-gb.html?label=cherrapunji-osVgFHJTV9V9IAeLvOpFigS392822631993%3Apl%3Ata%3Ap12%3Ap2%3Aac%3Aap%3Aneg%3Afi%3Atiaud-146342137270%3Akwd-30792628379%3Alp1007799%3Ali%3Adec%3Adm%3Appccp%3DUmFuZG9tSVYkc2RlIyh9YZVcNNsENnH02-pWD53qm9c&gclid=Cj0KCQjw6auyBhDzARIsALIo6v901vGcp34ucB62pIDTt2v5X3EFQtTuDHOFJazz66HUHu53v8H7GmMaAnPUEALw_wcB&aid=306395"><strong>Website:</strong> Abode Me Me Ai Haven</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
