<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>

        .card-img-top,
        .card-title {
            transition: transform 0.3s ease;
        }

        .card:hover .card-img-top {
            transform: scale(1.1);
        }
    </style>
    <title>Top Attractions in Chhattisgarh</title>
</head>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br>
    <div class="container mt-5">
        <h1 class="text-center mb-5" style="color: black;">Top Attractions in Chhattisgarh</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Raipur.php">
                        <img src="https://www.holidify.com/images/bgImages/RAIPUR.jpg" class="card-img-top" alt="Gulmarg Gondola" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Raipur</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Jagdalpur.php">
                        <img src="https://www.holidify.com/images/bgImages/JAGDALPUR.jpg" class="card-img-top" alt="Dal Lake" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Jagdalpur</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Dantewada.php">
                        <img src="https://www.holidify.com/images/bgImages/DANTEWADA.jpg" class="card-img-top" alt="Mughal Gardens, Srinagar" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Dantewada</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/30830702158_9dddea5e5f_z_20190327145849_20190327145909.jpg" class="card-img-top" alt="Shalimar Bagh Mughal Garden" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Mainpat</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/sirpurlakshmantemplebricks_20190319160652.jpg" class="card-img-top" alt="Vaishno Devi Mandir"height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Sirpur</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/18589052_1975002722525661_806815031434638557_o_20190315124930.jpg" class="card-img-top" alt="Amarnath Cave" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Madku Dweek</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php
        include_once "footer.html";
    ?>
</body>
</html>
