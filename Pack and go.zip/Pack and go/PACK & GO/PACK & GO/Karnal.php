<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Karnal</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Karnal</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t3.ftcdn.net/jpg/05/52/98/74/240_F_552987422_ba8wjsE1IMtGeHlRie5jBUTCvZ2OzeBa.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Karnal (pronunciationⓘ) is a city located in the state of Haryana, India and is the administrative headquarters of Karnal District. City is well connected as it lies on National Highway 01 , in the south of the city lies the city of Panipat, Sonepat and in the north lies Kurukshetra and Yamunanagar city while in the east lies the river Yamuna , on the other end of which lies Saharanpur and Shamli district of Uttar Pradesh on the eastern Bank. Karnal was used by the East India Company army as a refuge during the Indian Rebellion of 1857 in Delhi. The Battle of Karnal between Nader Shah of Persia and the Mughal Empire took place in this city in 1739.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Karnal" class="stretched-link">Want to know more about Karnal Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1c/b4/91/da/outdoor-venue.jpg?w=300&h=300&s=1" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Noormahal Palace</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g1584805-d1918405-Reviews-Noormahal_Palace-Karnal_Karnal_District_Haryana.html"><strong>Website:</strong>Noormahal Palace</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1a/84/1d/c5/capital-o-2361-gopinath.jpg?w=300&h=300&s=1" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title"> Gopinath the Grand Hotel</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g1584805-d7761876-Reviews-Gopinath_the_Grand_Hotel-Karnal_Karnal_District_Haryana.html"><strong>Website:</strong> Gopinath the Grand Hotel</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/22/4f/34/63/the-vivaan-hotels-resorts.jpg?w=300&h=300&s=1" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title">  The Vivaan Hotels & Resorts</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g1584805-d7950789-Reviews-The_Vivaan_Hotels_Resorts-Karnal_Karnal_District_Haryana.html"><strong>Website:</strong>  The Vivaan Hotels & Resorts</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
