
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">
    <style>
        .card-img-top,
        .card-title {
            transition: transform 0.3s ease;
        }

        .card:hover .card-img-top {
            transform: scale(1.1);
        }
    </style>
    <title>Top Attractions in Himachal</title>
</head>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br>
    <div class="container mt-5">
        <h1 class="text-center mb-5" style="color: black;">Top Attractions in Himachal</h1>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Solang Valley.php">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/shutterstock_633164246_20190904103856_20190904103926.jpg" class="card-img-top" alt="Gulmarg Gondola" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Solang Valley</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="Rohtang Pass.php">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/490_20190308180742.jpg" class="card-img-top" alt="Dal Lake" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Rohtang Pass</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="The Ridge.php">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/1913_20190523190338.jpg" class="card-img-top" alt="Mughal Gardens, Srinagar" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">The Ridge</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="	https://www.holidify.com/images/cmsuploads/raw/shutterstock_373549981_20190822151440.jpg" class="card-img-top" alt="Shalimar Bagh Mughal Garden" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Mall Road,Shimla</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://sun-b2b.s3.us-east-2.amazonaws.com/attraction/2023-03-14things16-10-31.jpg" class="card-img-top" alt="Vaishno Devi Mandir"height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Namgyal Monastery</h5>
                        </div>
                    </a>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card mb-4">
                    <a href="#">
                        <img src="https://www.holidify.com/images/cmsuploads/compressed/attr_1888_20190308172811.jpg" class="card-img-top" alt="Amarnath Cave" height="230px">
                        <div class="card-body">
                            <h5 class="card-title">Hidamba Temple</h5>
                        </div>
                    </a>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <?php
        include_once "footer.html";
    ?>
</body>
</html>
