<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        .container h1{
             color: #86B817;
        }
        .cmnt, .head{
            padding: 10px;
            margin: 10px;
        }
        
    </style>
</head>
<body>
    <?php
    include_once "Navbar.php";
    ?><br><br><br>
    <form action="" method="post">
    <div>
        <div class="head py-5">
            <h1><span class="text-primary">Testimonial</span></h1>
            <div><h3>---Write your review here---</h3></div>
        </div>
    </div>
    <div class="cmnt">
        <label for="name"><b>Name:</b></label><br>
        <input type="text" name="name"><br><br>
        <label for="email"><b>Place:</b></label>
        <textarea name="place" id="address" cols="30" rows="10"></textarea><br><br>
        <label for="comment"><b>Review:</b></label><br>
        <textarea name="comment" id="comment" cols="70" rows="8"></textarea><br><br>
        <input type="submit" name="submit" value="Done">
       <a href="reviewdisplay.php"><input type="submit" name="back" value="Back"></a>

    </div>
    </form>
    <?php
    include_once "footer.html";
    ?> 
</body>
<?php
    if(isset($_POST['submit']))
    {
        require_once "connect.php";
        $name=$_POST['name'];
        $place=$_POST['place'];
        $comment=$_POST['comment'];
        

        $qry="INSERT INTO reviews VALUES('','$name','$place','$comment')";
        $res=$conn->query($qry);
        // if($res){
        //     echo 'Comment saved';
        // }
        // else{
        //     echo 'not done';
        // }
        $conn->close();
    }

    ?>
</html>