<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>About Jorhat</title>
    <!-- Bootstrap CSS -->
    <link
      href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
      rel="stylesheet"
      integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH"
      crossorigin="anonymous"
    />
    <link
      rel="stylesheet"
      href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css"
    />
  </head>
  <style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
  <body>
  <?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
      <div class="row">
        <div class="col-12">
          <header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Jorhat</h1>
            </div>
          </header>
          <div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img
                src="https://t3.ftcdn.net/jpg/06/23/71/28/240_F_623712843_C4U3qvue8QrL9Zmppsja2OIexgI8na5D.jpg"
                class="w-100"
                alt="..."
              />
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>
                Jorhat (/ˈdʒɔːrhɑːt/ ⓘ JOR-haht) is a city and a growing urban
                centre in the state of Assam in India. Jorhat was the last
                capital of the Ahoms which lasted for at least 37 years. This
                town was settled near the Dichoi river, and a number of market
                were set near Dichoi, such as Phukanar Hat and Mashar Hat, thus
                this place came to be known as Jorhat (twin- market). During the
                period of Moamoria rebellion, Johat (then known Dichai) attained
                importance, with Ahom premier Purnananda Burhagohain encampment
                at Dichai fort. To keep out the Moamoria rebel intrusion he made
                the Bibudhi Garh (or the perplexing fort as called by the
                rebels). The Ahom capital was finally shifted in 1794 from
                Rangpur to here, which it remained till the fall of Ahom kingdom
                in 1838.
              </p>
              <div>
                <a
                  href="https://en.wikipedia.org/wiki/Jorhat"
                  class="stretched-link"
                  >Want to know more about Jorhat Click</a
                >
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div class="container mt-5">
      <div class="row">
        <div class="col-md-4">
          <div class="card">
            <img
              src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/03/4e/00/be/kaziranga-golf-resort.jpg?w=300&h=300&s=1"
              class="card-img-top"
              alt="PALM BLISS"
              height="300px"
            />
            <div class="card-body">
              <h5 class="card-title">Kaziranga Golf Resort</h5>
              <p class="card-text">
                <strong>Reviews:</strong>
                4.4/5 (1,204 reviews)
              </p>
              <p class="card-text">
                <strong>Type:</strong>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i> 5-star hotel
              </p>
              <p class="card-text"><strong>Amenities:</strong> Spa, Pool</p>
              <p class="card-text">
                <a
                  href="https://www.tripadvisor.in/Hotel_Review-g1155926-d2639101-Reviews-Kaziranga_Golf_Resort-Jorhat_Jorhat_District_Assam.html"
                  ><strong>Website:</strong>Kaziranga Golf Resort</a
                >
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <img
              src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1d/74/fe/25/facade.jpg?w=300&h=300&s=1"
              class="card-img-top"
              alt="Sterling Palm Bliss - Rishikesh"
              height="300px"
            />
            <div class="card-body">
              <h5 class="card-title">Hotel Gulmohar Grand</h5>
              <p class="card-text">
                <strong>Reviews:</strong>
                4.4/5 rating (1,629 reviews)
              </p>
              <p class="card-text">
                <strong>Type:</strong>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
              </p>
              <p class="card-text">
                <strong>Amenities:</strong> Spa, Child-friendly
              </p>
              <p class="card-text">
                <a
                  href="https://www.tripadvisor.in/Hotel_Review-g1155926-d15076166-Reviews-Hotel_Gulmohar_Grand-Jorhat_Jorhat_District_Assam.html"
                  ><strong>Website:</strong>Hotel Gulmohar Grand</a
                >
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-4">
          <div class="card">
            <img
              src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/01/f5/7b/5a/hotel-jora-palace.jpg?w=300&h=300&s=1"
              class="card-img-top"
              alt="GANGA KINARE - A Riverfront Heritage Hotel"
              height="300px"
            />
            <div class="card-body">
              <h5 class="card-title">Hotel Jora Palace</h5>
              <p class="card-text">
                <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
              </p>
              <p class="card-text">
                <strong>Type:</strong>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i> 4-star hotel
              </p>
              <p class="card-text"><strong>Amenities:</strong> Hot tub, Spa</p>
              <p class="card-text">
                <a
                  href="https://www.tripadvisor.in/Hotel_Review-g1155926-d1947923-Reviews-Hotel_Jora_Palace-Jorhat_Jorhat_District_Assam.html"
                  ><strong>Website:</strong>Hotel Jora Palace</a
                >
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
    <?php
        include_once "footer.html";
    ?>
    <script
      src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
      integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
      crossorigin="anonymous"></script>
  </body>
</html>
