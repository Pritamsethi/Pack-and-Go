<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link href="css/style2.css">
    <style>
      body{
        background-color: rgb(187,143,206);
      }
      h3{
        color: purple;
      }
    </style>
  </head>
  <body>
  <nav class="navbar bg-body-tertiary">
  <div class="container-fluid">
    <a class="navbar-brand" href="admin.php">
      <h3>Home</h3>  
    </a>
  </div>
</nav>
  <div >
    <div>
        <h3 class="text-center text-white p2 bg-dark bg-gradient text-uppercase">List of all Users</h3><br><br>
    </div>
  </div>  
  <div cllass="container mt-5">
    
  <table class="table table-responsive table-bordered border-dark tabel hover text-center">
  <tr class="table-warning table-active text-white">
    <th>FIRST NAME</th>
    <th>LAST NAME</th>
    <th>EMAIL</th>
    <th>OPERATION</th>
  </tr>
  <?php
    require_once "connect.php";

    $qry="SELECT * FROM users";
    $res = $conn->query($qry);
    while($row=$res->fetch_assoc()){
    ?>
    <tr>
        <td><?php echo $row['firstname']; ?></td>
        <td><?php echo $row['lastname']; ?></td>
        <td><?php echo $row['email']; ?></td>
        <td><a href="deleteuser.php?id=<?php echo $row['id']; ?>"><button class="bg-warning">DELETE</button></a></td>
    </tr>
    <?php
    }
    ?>
  </table>
  </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  </body>
</html>