
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Rishikesh</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
    
  </style>
<body>
    
    <?php
        include_once "Navbar.php";
    ?><br><br><br><br><br><br>
    
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Rishikesh</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://as2.ftcdn.net/v2/jpg/02/74/60/21/1000_F_274602185_8LiwDPAmnLs3JVCFzkG9mTpOY5PUaeIZ.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Rishikesh, also spelt as Hrishikesh, is a city near Dehradun in Dehradun district of the Indian state Uttarakhand. It is situated on the right bank of the Ganges River and is a pilgrimage town for Hindus, with ancient sages and saints meditating here in search of higher knowledge. There are numerous temples and ashrams built along the banks of the river.

                It is known as the "Gateway to the Garhwal Himalayas" and "Yoga Capital of the World".The city has hosted the annual "International Yoga Festival" on the first week of March since 1999. Rishikesh is a vegetarian-only and alcohol-free city.
                
                The Tehri Dam is located 86 km (53 mi) away from Rishikesh. Uttarkashi, a popular yoga destination, is 170 km (110 mi) uphill on the way to Gangotri. Rishikesh is the starting point for traveling to the four Chota Char Dham pilgrimage places: Badrinath, Kedarnath, Gangotri, and Yamunotri. It is also a starting point for Himalayan tourist destinations such as Harsil, Chopta, Auli, as well as summer and winter trekking destinations like Dodital, Dayara Bugyal, Kedarkantha and Har Ki Dun.
                
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Rishikesh" class="stretched-link">Want to know more about Rishikesh Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://lh3.googleusercontent.com/proxy/EsS_M61mPT89YnhN7UKKpi6P5_RXUGajh373ucpdRwnqDi37Ax5a2tpY_p0xLgueJ2FHg2fuXRI0vOURcpFgxhSsYZyrQ0m6AWV9YiinwlhuBYqE6BY2xQXguvu_YPjnPnxTIur0lfREt4okC-Da83TmHuEA9w=w472-h352-n-k" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Anand Kashi By The Ganges, Rishikesh</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.expedia.co.in/Narendranagar-Hotels-Anand-Kashi-By-The-Ganges.h16373362.Hotel-Information?chkin=2024-04-27&chkout=2024-04-28&x_pwa=1&rfrr=HSR&pwa_ts=1714067161718&referrerUrl=aHR0cHM6Ly93d3cuZXhwZWRpYS5jby5pbi9Ib3RlbC1TZWFyY2g%3D&useRewards=false&rm1=a2&regionId=602009&destination=Narendranagar%2C+Uttarakhand%2C+India&destType=MARKET&selected=16373362&latLong=30.16357%2C78.287216&sort=RECOMMENDED&top_dp=86000&top_cur=INR&mdpcid=IN.META.HPA.HOTEL-CORESEARCH-desktop-PROMOTED.HOTEL&mdpdtl=HTL.16373362.20240427.20240428.DDT.2.CID.20898087060.AUDID..RRID.bex_in_desktop&mctc=10&gclid=Cj0KCQjw_qexBhCoARIsAFgBleuUkRn4sA7g7PPiSL6AT82oezk6iWJkTBa7DVfSq3ae5_oa1zPjmqAaAneUEALw_wcB&userIntent=&selectedRoomType=316631804&selectedRatePlan=386442098&searchId=f3073ba1-9be5-4cc4-9b74-972551c97796&propertyName=Anand+Kashi+By+The+Ganges%2C+Rishikesh+%E2%80%93+IHCL+SeleQtions"><strong>Website:</strong> Anand Kashi</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://lh3.googleusercontent.com/proxy/FUgq2K47o7sx7jNB0mUd-A0aipFbDydnd3DFIzMgEtSMtnNpNceB_XaSmzkBqmJcOJO9vkj-IPKpdVmvOoaQXl3Ae28pmDeh8sCrUL4VZF0pR5sR-3uZP-f6wdk5T7LnuxIxwdHMKT-Ldb5TDE1KyB0zQISiAbE=w472-h352-n-k" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px"/>
              <div class="card-body">
                <h5 class="card-title">Sterling Palm Bliss - Rishikesh</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.agoda.com/palm-bliss-resorts/hotel/rishikesh-in.html?finalPriceView=1&isShowMobileAppPrice=false&cid=1918349&numberOfBedrooms=&familyMode=false&adults=2&children=0&rooms=1&maxRooms=0&checkIn=2024-04-27&isCalendarCallout=false&childAges=&numberOfGuest=0&missingChildAges=false&travellerType=1&showReviewSubmissionEntry=false&currencyCode=INR&isFreeOccSearch=false&isCityHaveAsq=false&pushId=CgYIgICxsQYSBgiAo7axBhgBII3JhgkqDBgBKggiAggBKgIIBA%3D%3D040ffcbf-4392-9853-edf5-f6a742cc054c_20240425_21&los=1&searchrequestid=4fac3916-b1a1-46fa-9299-dbef0ebb1506&ds=k5pGXa4s6AzbyIu3"><strong>Website:</strong>Sterling Palm Bliss</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://lh3.googleusercontent.com/proxy/YcVYp130FlxD9lL4Pn5CDVc5L0eDTOgp5fB48Fk7F-h9s1d00cxmmMebP6y_sGkrctBHt98ghf0exu8bMEwz4DsATxrpay9Qavv2zBrVl3Tv0JtWrCNdjjqhYRCzaxJdL9XdI78VI7YRbJ1FQge3TWQgbLUVtNY=w472-h352-n-k" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel"height="300px" />
              <div class="card-body">
                <h5 class="card-title">GANGA KINARE-A Riverfront Heritage</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.booking.com/hotel/in/ganga-kinare.en-gb.html?aid=1288252&label=metagha-link-LUIN-hotel-470749_dev-desktop_los-1_bw-2_dow-Saturday_defdate-1_room-0_gstadt-2_rateid-public_aud-0_gacid-17479522077_mcid-10_ppa-1_clrid-0_ad-1_gstkid-0_checkin-20240427_ppt-&sid=d0d4c968d398ce2981cb6126e206ec9b&all_sr_blocks=47074901_369960168_2_41_0;checkin=2024-04-27;checkout=2024-04-28;dest_id=-2109472;dest_type=city;dist=0;group_adults=2;group_children=0;hapos=1;highlighted_blocks=47074901_369960168_2_41_0;hpos=1;matching_block_id=47074901_369960168_2_41_0;no_rooms=1;req_adults=2;req_children=0;room1=A%2CA;sb_price_type=total;sr_order=popularity;sr_pri_blocks=47074901_369960168_2_41_0__1400000;srepoch=1714068467;srpvid=f1047f79d61201eb;type=total;ucfs=1&#hotelTmpl"><strong>Website:</strong> GANGA KINARE</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
      ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
