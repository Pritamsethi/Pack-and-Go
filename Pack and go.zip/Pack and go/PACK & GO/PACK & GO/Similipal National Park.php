<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Similipal National Park</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
  <?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Similipal National Park</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://www.swostiindia.com/admin/images/packageimage/TRIP%20TO%20SIMILIPAL%20NATIONALPARK659.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Simlipal National Park is a national park and tiger reserve in the Mayurbhanj district in the Indian state of Odisha covering 2,750 km2 (1,060 sq mi). It is part of the Mayurbhanj Elephant Reserve, which includes three protected areas, Similipal Tiger Reserve, Hadgarh Wildlife Sanctuary with 191.06 km2 (73.77 sq mi) and Kuldiha Wildlife Sanctuary with 272.75 km2 (105.31 sq mi).[1] Simlipal National Park derives its name from the abundance of red silk cotton trees growing in the area.[2]

                The park is home to Bengal tiger, Asian elephant, gaur, and chausingha.
                
                This protected area is part of the UNESCO World Network of Biosphere Reserves since 2009.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Simlipal_National_Park" class="stretched-link">Want to know more about Similipal Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/19/ce/cf/7d/similipal-resort.jpg?w=1200&h=-1&s=1" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Similipal Resort</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g12389551-d15450446-Reviews-Similipal_Resort-Mayurbhanj_District_Odisha.html"><strong>Website:</strong>Similipal Resort</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/17/b3/2f/13/the-empress-suite.jpg?w=300&h=300&s=1" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">The Belgadia Palace</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g2287521-d16814450-Reviews-The_Belgadia_Palace-Baripada_Mayurbhanj_District_Odisha.html"><strong>Website:</strong>The Belgadia Palace</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://dynamic-media-cdn.tripadvisor.com/media/photo-o/1d/5d/f8/5c/similipal-eco-cottage.jpg?w=300&h=300&s=1" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Similipal Eco Cottage</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g2287521-d23537236-Reviews-Similipal_Eco_Cottage-Baripada_Mayurbhanj_District_Odisha.html"><strong>Website:</strong>Similipal Eco Cottage</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
