<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>About Chilika Lake</title>
  <!-- Bootstrap CSS -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" />
</head>
<style>
    .container {
      text-align: center;
    }
    .carousel {
      width: 300px;
      margin-top: 20px;
    }
  </style>
<body>
<?php
        include_once "Navbar.php";
    ?><br><br><br><br><br>
    <div class="container">
        <div class="row">
          <div class="col-12"><header class="bg-dark py-3">
            <div class="container">
              <h1 class="text-light text-center">About Chilika Lake</h1>
            </div>
          </header><div class="row g-0 bg-body-secondary position-relative">
            <div class="col-md-6 mb-md-0 p-md-4">
              <img src="https://t3.ftcdn.net/jpg/03/62/77/20/240_F_362772024_23Is2sNIBbzH4an1ZkVFJGwpGsJzWE7P.jpg" class="w-100" alt="...">
            </div>
            <div class="col-md-6 mb-md-0 p-md-4">
              <h3 class="mt-0">Introduction</h3>
              <p>Chilika Lake is the largest brackish water lagoon in Asia and second largest coastal lagoon in the world, spread over the Puri, Khordha and Ganjam districts of Odisha state on the east coast of India, at the mouth of the Daya River, flowing into the Bay of Bengal, covering an area of over 1,100 square kilometres (420 sq mi).

                Chilika Lake comes after the New Caledonian barrier reef.[4][5][6] It has been listed as a tentative UNESCO World Heritage site.[7] Its salinity varies by region, from freshwater where rivers flow in, to oceanic salinity levels due to tidal influx.
              </p>
              <div>
              <a href="https://en.wikipedia.org/wiki/Chilika_Lake" class="stretched-link">Want to know more about Chilika Click</a></div>
            </div>
          </div></div>
        </div>
      </div>
      <div class="container mt-5">
        <div class="row">
          <div class="col-md-4">
            <div class="card">
              <img src="https://lh3.googleusercontent.com/gps-proxy/ALd4DhHVftKRtbVN-lpmhpfmeZmAQvCZOGz1V6j4xvDy9hI0n6ecs1GUYmDoMBp6876EvDi8gm_07hO39nddNPlfbwcZrXuvf-HXtmgW7f2lQBED4RQobukQEbvcUAErHtX2d1LGB6RGzzFiBfCXX8okN895SSnwd4-UVw7W9B4w4iw6bQmv_i0B4qrB=w287-h192-n-k-rw-no-v1" class="card-img-top" alt="PALM BLISS" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Eco-Cottage Chilika Island Resort</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 
                  4.4/5 (1,204 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i> 5-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Pool
                </p>
                <p class="card-text">
                  <a href="https://www.google.com/travel/search?q=hotels%20in%20chilika%20lake&g2lb=2503771%2C2503781%2C4284970%2C4814050%2C4874190%2C4893075%2C4965990%2C72277293%2C72302247%2C72317059%2C72406588%2C72414906%2C72421566%2C72458066%2C72462234%2C72470440%2C72470899%2C72471280%2C72472051%2C72473841%2C72481459%2C72485658%2C72486593%2C72494250%2C72513422%2C72513513%2C72530238%2C72536387%2C72538597%2C72543209%2C72549171%2C72556202%2C72570850%2C72572527&hl=en-IN&gl=in&cs=1&ssta=1&ts=CAESCgoCCAMKAggDEAAaVQo3EjUyJTB4M2ExODFmNDkzNDI4MzY5YjoweDhjNzU2MmM2MGJjZGE3YTE6DENoaWxpa2EgTGFrZRIaEhQKBwjoDxAFGAgSBwjoDxAFGAkYATICEAAqBwoFOgNJTlI&qs=CAEyKENob0lyOW5CdmZEZXlaWFdBUm9OTDJjdk1URjBOblp1WkhnM09SQUI4BkIJCR9mdauMogSLQgkJ0jk5odoxkXVCCQmvm4v49wrEzVpQMk6qAUsQASoKIgZob3RlbHMoADIfEAEiGwovWMQdmDwwdKY8pxbRKgu1R5CNvmw5mBN-izIaEAIiFmhvdGVscyBpbiBjaGlsaWthIGxha2U&ap=KigKEgnbVMqtO-YyQBHMeFtpdDhVQBISCVAE_0rhhzRAEcx4W2n3eFVAMABoAQ&ictx=111&ved=0CAAQ5JsGahgKEwiQq_-ihPuFAxUAAAAAHQAAAAAQmQE"><strong>Website:</strong>Eco-Cottage Chilika Island Resort</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://media-cdn.tripadvisor.com/media/photo-s/1c/d4/48/2a/swimming-pool-with-villas.jpg" class="card-img-top" alt="Sterling Palm Bliss - Rishikesh" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Swosti Chilika Resort</h5>
                <p class="card-text">
                  <strong>Reviews:</strong>
                   4.4/5 rating (1,629 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong> 
                  <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-solid fa-star"></i>
                <i class="fa-regular fa-star"></i>4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Spa, Child-friendly
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g13986495-d12342253-Reviews-Swosti_Chilika_Resort-Pathara_Ganjam_District_Odisha.html"><strong>Website:</strong>Swosti Chilika Resort</a>
                </p>
              </div>
            </div>
          </div>
          <div class="col-md-4">
            <div class="card">
              <img src="https://media-cdn.tripadvisor.com/media/photo-s/0d/b8/8a/be/way-to-chilika.jpg" class="card-img-top" alt="GANGA KINARE - A Riverfront Heritage Hotel" height="300px" />
              <div class="card-body">
                <h5 class="card-title">Panthanivas Rambha</h5>
                <p class="card-text">
                  <strong>Reviews:</strong> 4.3/5 rating (3,077 reviews)
                </p>
                <p class="card-text">
                  <strong>Type:</strong>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-solid fa-star"></i>
                  <i class="fa-regular fa-star"></i> 4-star hotel
                </p>
                <p class="card-text">
                  <strong>Amenities:</strong> Hot tub, Spa
                </p>
                <p class="card-text">
                  <a href="https://www.tripadvisor.in/Hotel_Review-g1584848-d1585607-Reviews-Panthanivas_Rambha-Rambha_Ganjam_District_Odisha.html"><strong>Website:</strong>Panthanivas Rambha</a>
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
      <?php
        include_once "footer.html";
    ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
