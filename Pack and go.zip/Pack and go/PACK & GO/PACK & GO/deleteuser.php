<?php
    if(!isset($_GET['id'])){
        header("location:adminuser.php");
    }
    require_once "connect.php";
    $uid=$_GET['id'];
    $qry="DELETE FROM users WHERE id=$uid";
    if($conn->query($qry)){
        header("location:adminuser.php?status=ok");
    }