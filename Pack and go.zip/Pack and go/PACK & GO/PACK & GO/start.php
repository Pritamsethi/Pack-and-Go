<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style>
        body{
            margin: 0;
            padding: 0;
            font-family: 'Franklin Gothic Medium', 'Arial Narrow', Arial, sans-serif;
        }
        .container{
            position: absolute;
            left: 0;
            top: 0;
            width: 100%;
            height: 100vh;
            animation: animate 16s  infinite;
            background-size: cover;
        }

        @keyframes animate{
            0%,100%{
                background-image: url(https://images.pexels.com/photos/355829/pexels-photo-355829.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);
            }
            25%{
                background-image: url(https://images.pexels.com/photos/2409681/pexels-photo-2409681.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);
            }
            50%{
                background-image: url(https://images.pexels.com/photos/2341830/pexels-photo-2341830.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);
            }
            75%{
                background-image: url(https://images.pexels.com/photos/1028381/pexels-photo-1028381.jpeg?auto=compress&cs=tinysrgb&w=600&lazy=load);
            }
            100%{
                background-image: url(https://images.pexels.com/photos/307008/pexels-photo-307008.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1);
            }

        }
        .details{
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            text-transform: uppercase;
            text-align: center;

        }
        .details h1{
            color: #fff;
            font-size: 60px;
            letter-spacing: 15px;
        }
        .details h2{
            color: #fff;
        }
        .details h1 span{
            color: #86B817;
        }
        .details a{
            background: #85c1ee;
            padding: 10px 24px;
            text-decoration: none;
            font-size: 18px;
            border-radius: 20px;
        }
        .details a:hover{
            background: #86B817;
            color: #fff;
        }
    </style>
</head>
<body> 
    <div class="container">
        <div class="outer">
            <div class="details">
                <h1><span>Pack & Go</span></h1>
                <a href="login.php">LOGIN</a>
            </div>
        </div>
    </div>
</body>
</html>
